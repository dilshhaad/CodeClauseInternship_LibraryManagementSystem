create database library;
drop database library;

select * from books;
insert into books value
(111,"Fundamentals of Wavelets","Goswami",1),(112,"Data Smart","Foreman",1),
(113,"God Created the Integers","Hawking",1),(114,"Superfreakonomics","Dubner",1),
(115,"Orientalism","Edward",1),(116,"Jurassic Park","Michael",1),
(117,"Freakonomics","Dubner",1),(118,"City of Joy","Dominique",1),
(119,"Free Will","Harris",1),(120,"Electric Universe","Bodanis",1);

select * from students;
insert into students value
(1001,"Vedant",1),(1002,"Vipul",2),(1003,"Ankit",4),
(1004,"Akash",0),(1005,"Raghav",1),(1006,"Akshay",0);